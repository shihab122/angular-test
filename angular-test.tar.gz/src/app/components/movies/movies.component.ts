import { Component, OnInit } from '@angular/core';
import {MovieService} from '../../services/movie.service';
import Handsontable from 'handsontable';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  dataset: any[] = [];
  hotSettings: Handsontable.GridSettings;

  id = 'movies-table';

  constructor(private movieService: MovieService) { }

  ngOnInit(): void {
    this.getMovies();
    this.hotSettings = this.setHotSettings([]);
  }

  getMovies(): any {
    this.movieService.getMovies().subscribe(data => {
      this.dataset = data;
      this.hotSettings = this.setHotSettings(data);
    }, error => {
      console.log(error);
    });
  }

  afterColumnMove(sourceIndex: any, targetIndex: any) {
    console.log(sourceIndex, targetIndex);
    // return true;
  }

  getColumns() {
    return [{
      data: 'id',
      renderer: (instance, td, row, col, prop, value, cellProperties) => {
        console.log(instance, td, row, col, prop, value, cellProperties);
      }
    }, {
      data: 'title'
    }, {
      data: 'budget',
    }];
  }

  getColHeaders() {
    return ['ID', 'Title', 'Budget'];
  }

  private setHotSettings(data: any) {
    return {
      data,
      colHeaders: this.getColHeaders(),
      rowHeaders: true,
      manualColumnMove: true,
      columns: this.getColumns(),
      licenseKey: 'non-commercial-and-evaluation',
      /*columns: [
        {},
        {
          renderer(instance, td, row, col, prop, value, cellProperties) {
            console.log('here');
          }
        }
      ],*/
    };
  }
}
