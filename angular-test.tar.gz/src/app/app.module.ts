import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { HotTableModule } from '@handsontable/angular';
import { AppComponent } from './app.component';
import { MoviesComponent } from './components/movies/movies.component';

@NgModule({
  declarations: [AppComponent, MoviesComponent],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, HotTableModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
